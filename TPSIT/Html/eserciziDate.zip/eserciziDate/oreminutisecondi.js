let oraAttuale = new Date();
console.log("Ora:", oraAttuale.getHours());
console.log("Minuti:", oraAttuale.getMinutes());
console.log("Secondi:", oraAttuale.getSeconds());
