let compleanno = new Date("2000-05-15");
console.log("La mia data di nascita è:", compleanno);

// Giorno della settimana in italiano
let giornoSettimana = ["Domenica","Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato"];
console.log("Ero nato di:", giornoSettimana[compleanno.getDay()]);
